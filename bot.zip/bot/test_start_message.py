"""Checks that the private /start handler sends the requested welcome."""

from __future__ import annotations

import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from bot.economy import EconomyStore
from bot.main import private_start_message, start_command

EXPECTED_WELCOME = (
    "🔥 WLS MAFIA botiga xush kelibsiz!\n\n"
    "🎭 Mafia o‘yiniga qo‘shiling.\n"
    "Guruhda /mafia buyrug‘i orqali yangi o‘yin boshlang.\n"
    "Rolingizni olish uchun avval shu shaxsiy chatda /start bosing."
)


class StartMessageTests(unittest.IsolatedAsyncioTestCase):
    async def test_private_start_sends_requested_welcome_and_profile_help(self) -> None:
        update = SimpleNamespace(
            effective_chat=SimpleNamespace(id=100, type="private"),
            effective_user=SimpleNamespace(
                id=12345,
                full_name="Test O‘yinchi",
                username="test_player",
            ),
        )
        context = SimpleNamespace()

        with tempfile.TemporaryDirectory() as directory:
            store = EconomyStore(directory)
            with (
                patch("bot.main.economy_store", store),
                patch("bot.main.safe_send", new_callable=AsyncMock) as send,
            ):
                await start_command(update, context)

        sent_text = send.await_args.args[2]
        self.assertTrue(sent_text.startswith(f"{EXPECTED_WELCOME}\n\n"))
        self.assertIn("/profile, /shop, /inventory", sent_text)

    def test_missing_profile_keeps_exact_requested_text(self) -> None:
        self.assertEqual(private_start_message(None), EXPECTED_WELCOME)


if __name__ == "__main__":
    unittest.main()

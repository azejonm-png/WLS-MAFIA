"""Persistent virtual-currency profiles, shop purchases, and game rewards."""

from __future__ import annotations

import json
import os
import random
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

STARTING_DOLLARS = 500
STARTING_DIAMONDS = 2
GAME_DOLLAR_REWARD = 100
WIN_DOLLAR_BONUS = 250
WIN_DIAMOND_REWARD = 1
VIP_DURATION_DAYS = 30
VIP_DURATION_SECONDS = VIP_DURATION_DAYS * 24 * 60 * 60
PREMIUM_DURATION_DAYS = 30
PREMIUM_DURATION_SECONDS = PREMIUM_DURATION_DAYS * 24 * 60 * 60
DAILY_BASE_DOLLARS = 250
DAILY_BASE_DIAMONDS = 1

SHOP_CATEGORIES = {
    "memberships": "👑 A’zoliklar",
    "protection": "🛡 Himoya",
    "chests": "🎁 Sanduqlar",
    "badges": "🏷 Nishonlar",
}


@dataclass(frozen=True)
class ShopItem:
    item_id: str
    name: str
    description: str
    category: str
    dollar_price: int | None = None
    diamond_price: int | None = None
    vip_days: int = 0
    premium_days: int = 0


SHOP_ITEMS = {
    "vip30": ShopItem(
        item_id="vip30",
        name="VIP — 30 kun",
        description="O‘yin dollar mukofotlarini 2 baravar, kunlik diamondni 1 taga oshiradi.",
        category="memberships",
        dollar_price=1500,
        diamond_price=8,
        vip_days=VIP_DURATION_DAYS,
    ),
    "premium30": ShopItem(
        item_id="premium30",
        name="Premium — 30 kun",
        description="O‘yin dollarlarini 3 baravar, g‘alaba va kunlik diamondlarni 2 baravar beradi.",
        category="memberships",
        dollar_price=4000,
        diamond_price=20,
        premium_days=PREMIUM_DURATION_DAYS,
    ),
    "night_shield": ShopItem(
        item_id="night_shield",
        name="Tungi qalqon",
        description="Keyingi o‘yinda bir mafiya hujumidan saqlaydi.",
        category="protection",
        dollar_price=600,
        diamond_price=2,
    ),
    "chest_basic": ShopItem(
        item_id="chest_basic",
        name="Oddiy sandiq",
        description="Dollar, diamond, qalqon yoki qisqa VIP mukofoti chiqishi mumkin.",
        category="chests",
        dollar_price=300,
        diamond_price=1,
    ),
    "chest_rare": ShopItem(
        item_id="chest_rare",
        name="Noyob sandiq",
        description="Kattaroq valyuta, qalqon yoki Premium muddati yutib oling.",
        category="chests",
        dollar_price=1200,
        diamond_price=5,
    ),
    "badge_detective": ShopItem(
        item_id="badge_detective",
        name="Komissar nishoni",
        description="Profilingizga Komissar nishonini taqing.",
        category="badges",
        dollar_price=350,
    ),
    "badge_mafia": ShopItem(
        item_id="badge_mafia",
        name="Mafiya nishoni",
        description="Profilingizga Mafiya nishonini taqing.",
        category="badges",
        dollar_price=350,
    ),
    "badge_city": ShopItem(
        item_id="badge_city",
        name="Shahar posboni nishoni",
        description="Profilingizga Shahar posboni nishonini taqing.",
        category="badges",
        dollar_price=500,
    ),
}

CHEST_REWARDS = {
    "chest_basic": [
        {"kind": "dollars", "amount": 150, "weight": 38, "label": "$150"},
        {"kind": "dollars", "amount": 300, "weight": 27, "label": "$300"},
        {"kind": "diamonds", "amount": 1, "weight": 15, "label": "1 diamond"},
        {"kind": "diamonds", "amount": 2, "weight": 5, "label": "2 diamond"},
        {
            "kind": "item",
            "item_id": "night_shield",
            "amount": 1,
            "weight": 12,
            "label": "Tungi qalqon",
        },
        {"kind": "vip_days", "amount": 1, "weight": 3, "label": "VIP — 1 kun"},
    ],
    "chest_rare": [
        {"kind": "dollars", "amount": 700, "weight": 30, "label": "$700"},
        {"kind": "dollars", "amount": 1200, "weight": 20, "label": "$1 200"},
        {"kind": "diamonds", "amount": 3, "weight": 20, "label": "3 diamond"},
        {"kind": "diamonds", "amount": 5, "weight": 8, "label": "5 diamond"},
        {
            "kind": "item",
            "item_id": "night_shield",
            "amount": 2,
            "weight": 12,
            "label": "2 ta Tungi qalqon",
        },
        {
            "kind": "premium_days",
            "amount": 1,
            "weight": 8,
            "label": "Premium — 1 kun",
        },
        {
            "kind": "premium_days",
            "amount": 3,
            "weight": 2,
            "label": "Premium — 3 kun",
        },
    ],
}


@dataclass
class PlayerProfile:
    user_id: int
    name: str
    username: str | None = None
    dollars: int = STARTING_DOLLARS
    diamonds: int = STARTING_DIAMONDS
    vip_until: float = 0
    premium_until: float = 0
    games_played: int = 0
    wins: int = 0
    inventory: dict[str, int] = field(default_factory=dict)
    active_badge: str | None = None
    protection_ready: bool = False
    last_daily_claim: str | None = None
    purchase_history: list[dict[str, object]] = field(default_factory=list)

    @property
    def is_vip(self) -> bool:
        return self.vip_until > time.time()

    @property
    def is_premium(self) -> bool:
        return self.premium_until > time.time()

    def to_dict(self) -> dict[str, object]:
        return {
            "user_id": self.user_id,
            "name": self.name,
            "username": self.username,
            "dollars": self.dollars,
            "diamonds": self.diamonds,
            "vip_until": self.vip_until,
            "premium_until": self.premium_until,
            "games_played": self.games_played,
            "wins": self.wins,
            "inventory": self.inventory,
            "active_badge": self.active_badge,
            "protection_ready": self.protection_ready,
            "last_daily_claim": self.last_daily_claim,
            "purchase_history": self.purchase_history,
        }

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> PlayerProfile:
        raw_inventory = data.get("inventory", {})
        if isinstance(raw_inventory, list):
            inventory: dict[str, int] = {}
            for item in raw_inventory:
                item_id = str(item)
                inventory[item_id] = inventory.get(item_id, 0) + 1
        elif isinstance(raw_inventory, dict):
            inventory = {
                str(item_id): max(0, int(count))
                for item_id, count in raw_inventory.items()
            }
        else:
            raise ValueError("Profile inventory must be a list or object.")
        history = data.get("purchase_history", [])
        if not isinstance(history, list):
            raise ValueError("Purchase history must be a list.")
        return cls(
            user_id=int(data["user_id"]),
            name=str(data.get("name", "O‘yinchi")),
            username=(
                str(data["username"])
                if data.get("username") is not None
                else None
            ),
            dollars=max(0, int(data.get("dollars", STARTING_DOLLARS))),
            diamonds=max(0, int(data.get("diamonds", STARTING_DIAMONDS))),
            vip_until=float(data.get("vip_until", 0)),
            premium_until=float(data.get("premium_until", 0)),
            games_played=max(0, int(data.get("games_played", 0))),
            wins=max(0, int(data.get("wins", 0))),
            inventory=inventory,
            active_badge=(
                str(data["active_badge"])
                if data.get("active_badge") is not None
                else None
            ),
            protection_ready=bool(data.get("protection_ready", False)),
            last_daily_claim=(
                str(data["last_daily_claim"])
                if data.get("last_daily_claim") is not None
                else None
            ),
            purchase_history=[dict(item) for item in history if isinstance(item, dict)],
        )


class EconomyStore:
    """Atomic local profile store used by unit tests and legacy imports."""

    def __init__(self, data_dir: str | None = None) -> None:
        directory = Path(data_dir or os.getenv("MAFIA_DATA_DIR", "data"))
        self.path = directory / "economy.json"
        self.profiles: dict[int, PlayerProfile] = {}
        self.settled_games: set[str] = set()
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError("Economy data must be a JSON object.")
            self._restore_snapshot(raw)
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise RuntimeError(f"Could not load saved player data from {self.path}.") from exc

    def _restore_snapshot(self, raw: dict[str, object]) -> None:
        raw_profiles = raw.get("profiles", {})
        raw_settled = raw.get("settled_games", [])
        if not isinstance(raw_profiles, dict) or not isinstance(raw_settled, list):
            raise ValueError("Economy profiles and settled games have invalid shapes.")
        self.profiles = {
            int(key): PlayerProfile.from_dict(value)
            for key, value in raw_profiles.items()
            if isinstance(value, dict)
        }
        self.settled_games = {str(game_id) for game_id in raw_settled}

    def _snapshot(self) -> dict[str, object]:
        return {
            "version": 2,
            "profiles": {
                str(user_id): profile.to_dict()
                for user_id, profile in self.profiles.items()
            },
            "settled_games": sorted(self.settled_games),
        }

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary_path = self.path.with_suffix(".json.tmp")
        temporary_path.write_text(
            json.dumps(self._snapshot(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        temporary_path.replace(self.path)

    def _get_or_create(
        self, user_id: int, name: str, username: str | None = None
    ) -> tuple[PlayerProfile, bool]:
        profile = self.profiles.get(user_id)
        if profile is None:
            profile = PlayerProfile(user_id=user_id, name=name, username=username)
            self.profiles[user_id] = profile
            return profile, True
        changed = profile.name != name or profile.username != username
        profile.name = name
        profile.username = username
        return profile, changed

    def ensure_profile(
        self, user_id: int, name: str, username: str | None = None
    ) -> PlayerProfile:
        profile, changed = self._get_or_create(user_id, name, username)
        if changed:
            self.save()
        return profile

    def get_profile(self, user_id: int) -> PlayerProfile | None:
        return self.profiles.get(user_id)

    def _record(
        self,
        profile: PlayerProfile,
        event_type: str,
        *,
        item_id: str | None = None,
        currency: str | None = None,
        amount: int | None = None,
        details: dict[str, object] | None = None,
        now: float | None = None,
    ) -> None:
        profile.purchase_history.append(
            {
                "type": event_type,
                "item_id": item_id,
                "currency": currency,
                "amount": amount,
                "details": details or {},
                "at": time.time() if now is None else now,
            }
        )

    @staticmethod
    def _add_inventory(profile: PlayerProfile, item_id: str, amount: int) -> None:
        next_count = profile.inventory.get(item_id, 0) + amount
        if next_count > 0:
            profile.inventory[item_id] = next_count
        else:
            profile.inventory.pop(item_id, None)

    def purchase(
        self,
        user_id: int,
        name: str,
        username: str | None,
        item_id: str,
        currency: str,
        now: float | None = None,
    ) -> str:
        item = SHOP_ITEMS.get(item_id)
        if item is None:
            return "not_found"
        if currency not in {"dollars", "diamonds"}:
            return "invalid_currency"
        price = (
            item.dollar_price if currency == "dollars" else item.diamond_price
        )
        if price is None:
            return "invalid_currency"

        profile, _ = self._get_or_create(user_id, name, username)
        if item.category == "badges" and profile.inventory.get(item_id, 0) > 0:
            return "already_owned"
        balance = profile.dollars if currency == "dollars" else profile.diamonds
        if balance < price:
            return "insufficient_funds"
        if currency == "dollars":
            profile.dollars -= price
        else:
            profile.diamonds -= price

        if item.vip_days:
            timestamp = time.time() if now is None else now
            profile.vip_until = max(timestamp, profile.vip_until) + (
                item.vip_days * 24 * 60 * 60
            )
        elif item.premium_days:
            timestamp = time.time() if now is None else now
            profile.premium_until = max(timestamp, profile.premium_until) + (
                item.premium_days * 24 * 60 * 60
            )
        else:
            self._add_inventory(profile, item_id, 1)
        self._record(
            profile,
            "purchase",
            item_id=item_id,
            currency=currency,
            amount=price,
            details={"name": item.name},
            now=now,
        )
        self.save()
        return "purchased"

    def equip_badge(
        self,
        user_id: int,
        item_id: str | None,
    ) -> str:
        profile = self.profiles.get(user_id)
        if profile is None:
            return "profile_missing"
        if item_id is None:
            profile.active_badge = None
            self.save()
            return "unequipped"
        item = SHOP_ITEMS.get(item_id)
        if (
            item is None
            or item.category != "badges"
            or profile.inventory.get(item_id, 0) <= 0
        ):
            return "not_owned"
        profile.active_badge = item_id
        self.save()
        return "equipped"

    def claim_daily(
        self,
        user_id: int,
        name: str,
        username: str | None,
        day_key: str,
        now: float | None = None,
    ) -> tuple[str, dict[str, int] | None]:
        profile, _ = self._get_or_create(user_id, name, username)
        if profile.last_daily_claim == day_key:
            return "already_claimed", None

        timestamp = time.time() if now is None else now
        if profile.premium_until > timestamp:
            dollars = DAILY_BASE_DOLLARS * 3
            diamonds = DAILY_BASE_DIAMONDS * 2
            membership = "premium"
        elif profile.vip_until > timestamp:
            dollars = DAILY_BASE_DOLLARS * 2
            diamonds = DAILY_BASE_DIAMONDS
            membership = "vip"
        else:
            dollars = DAILY_BASE_DOLLARS
            diamonds = DAILY_BASE_DIAMONDS
            membership = "standard"
        profile.dollars += dollars
        profile.diamonds += diamonds
        profile.last_daily_claim = day_key
        reward = {"dollars": dollars, "diamonds": diamonds}
        self._record(
            profile,
            "daily_reward",
            currency="mixed",
            details={**reward, "membership": membership, "day": day_key},
            now=timestamp,
        )
        self.save()
        return "claimed", reward

    def open_chest(
        self,
        user_id: int,
        chest_id: str,
        *,
        rng: random.Random | random.SystemRandom | None = None,
        now: float | None = None,
    ) -> tuple[str, dict[str, object] | None]:
        rewards = CHEST_REWARDS.get(chest_id)
        profile = self.profiles.get(user_id)
        if rewards is None:
            return "not_found", None
        if profile is None or profile.inventory.get(chest_id, 0) <= 0:
            return "no_chest", None

        generator = rng or random.SystemRandom()
        reward = generator.choices(
            rewards,
            weights=[int(item["weight"]) for item in rewards],
            k=1,
        )[0]
        timestamp = time.time() if now is None else now
        self._add_inventory(profile, chest_id, -1)
        amount = int(reward["amount"])
        kind = str(reward["kind"])
        if kind == "dollars":
            profile.dollars += amount
        elif kind == "diamonds":
            profile.diamonds += amount
        elif kind == "item":
            self._add_inventory(profile, str(reward["item_id"]), amount)
        elif kind == "vip_days":
            profile.vip_until = max(timestamp, profile.vip_until) + amount * 86400
        elif kind == "premium_days":
            profile.premium_until = (
                max(timestamp, profile.premium_until) + amount * 86400
            )
        else:
            raise ValueError(f"Unsupported chest reward: {kind}")

        result = {
            "kind": kind,
            "amount": amount,
            "label": str(reward["label"]),
            "item_id": reward.get("item_id"),
        }
        self._record(
            profile,
            "chest_open",
            item_id=chest_id,
            details={"reward": result},
            now=timestamp,
        )
        self.save()
        return "opened", result

    def activate_protection(self, user_id: int, now: float | None = None) -> str:
        profile = self.profiles.get(user_id)
        if profile is None:
            return "profile_missing"
        if profile.protection_ready:
            return "already_active"
        if profile.inventory.get("night_shield", 0) <= 0:
            return "not_owned"
        self._add_inventory(profile, "night_shield", -1)
        profile.protection_ready = True
        self._record(
            profile,
            "protection_armed",
            item_id="night_shield",
            details={"applies_to": "next_game"},
            now=now,
        )
        self.save()
        return "activated"

    def cancel_protection(self, user_id: int, now: float | None = None) -> str:
        profile = self.profiles.get(user_id)
        if profile is None:
            return "profile_missing"
        if not profile.protection_ready:
            return "not_active"
        profile.protection_ready = False
        self._add_inventory(profile, "night_shield", 1)
        self._record(
            profile,
            "protection_cancelled",
            item_id="night_shield",
            details={"returned_to_inventory": True},
            now=now,
        )
        self.save()
        return "cancelled"

    def consume_protection(self, user_id: int) -> bool:
        profile = self.profiles.get(user_id)
        if profile is None or not profile.protection_ready:
            return False
        profile.protection_ready = False
        self._record(
            profile,
            "protection_equipped",
            item_id="night_shield",
            details={"applies_to": "next_game"},
        )
        self.save()
        return True

    def settle_game(
        self,
        game_id: str,
        players: Iterable[object],
        winning_team: str,
        now: float | None = None,
    ) -> dict[int, dict[str, int | bool]]:
        """Award each game once, writing balances and settlement ID atomically."""
        if game_id in self.settled_games:
            return {}

        timestamp = time.time() if now is None else now
        rewards: dict[int, dict[str, int | bool]] = {}
        for player in players:
            user_id = int(getattr(player, "user_id"))
            name = str(getattr(player, "name"))
            username = getattr(player, "username", None)
            role = getattr(getattr(player, "role", None), "value", None)
            won = (
                role == "mafia"
                if winning_team == "mafia"
                else role is not None and role != "mafia"
            )
            profile, _ = self._get_or_create(user_id, name, username)
            base_dollars = GAME_DOLLAR_REWARD + (WIN_DOLLAR_BONUS if won else 0)
            if profile.premium_until > timestamp:
                multiplier = 3
                diamonds = 2 * WIN_DIAMOND_REWARD if won else 0
                membership = "premium"
            elif profile.vip_until > timestamp:
                multiplier = 2
                diamonds = WIN_DIAMOND_REWARD if won else 0
                membership = "vip"
            else:
                multiplier = 1
                diamonds = WIN_DIAMOND_REWARD if won else 0
                membership = "standard"
            dollars = base_dollars * multiplier
            profile.dollars += dollars
            profile.diamonds += diamonds
            profile.games_played += 1
            if won:
                profile.wins += 1
            self._record(
                profile,
                "game_reward",
                details={
                    "game_id": game_id,
                    "dollars": dollars,
                    "diamonds": diamonds,
                    "won": won,
                    "membership": membership,
                },
                now=timestamp,
            )
            rewards[user_id] = {
                "dollars": dollars,
                "diamonds": diamonds,
                "won": won,
            }

        self.settled_games.add(game_id)
        self.save()
        return rewards


class PostgresEconomyStore(EconomyStore):
    """PostgreSQL-backed economy state that survives bot and workspace restarts."""

    def __init__(
        self,
        data_dir: str | None = None,
        *,
        dsn: str | None = None,
        state_key: str = "wls_mafia",
    ) -> None:
        self.dsn = dsn or os.getenv("DATABASE_URL")
        if not self.dsn:
            raise RuntimeError("DATABASE_URL is required for permanent player data.")
        self.state_key = state_key
        super().__init__(data_dir)

    def load(self) -> None:
        import psycopg
        from psycopg.types.json import Jsonb

        try:
            with psycopg.connect(self.dsn) as connection:
                row = connection.execute(
                    "SELECT payload FROM mafia_economy_state WHERE state_key = %s",
                    (self.state_key,),
                ).fetchone()
                if row is not None:
                    payload = row[0]
                    if isinstance(payload, str):
                        payload = json.loads(payload)
                    if not isinstance(payload, dict):
                        raise ValueError("The saved economy payload is invalid.")
                    self._restore_snapshot(payload)
                    return

                if self.path.exists():
                    legacy = json.loads(self.path.read_text(encoding="utf-8"))
                    if not isinstance(legacy, dict):
                        raise ValueError("The legacy economy file is invalid.")
                    self._restore_snapshot(legacy)

                connection.execute(
                    """
                    INSERT INTO mafia_economy_state (state_key, payload)
                    VALUES (%s, %s)
                    ON CONFLICT (state_key) DO NOTHING
                    """,
                    (self.state_key, Jsonb(self._snapshot())),
                )
                row = connection.execute(
                    "SELECT payload FROM mafia_economy_state WHERE state_key = %s",
                    (self.state_key,),
                ).fetchone()
                if row is None:
                    raise RuntimeError("Could not initialize economy state.")
                payload = row[0]
                if isinstance(payload, str):
                    payload = json.loads(payload)
                if not isinstance(payload, dict):
                    raise ValueError("The saved economy payload is invalid.")
                self._restore_snapshot(payload)
        except Exception as exc:
            raise RuntimeError(
                "Could not load player data from PostgreSQL. "
                "Check the development database schema and connection."
            ) from exc

    def save(self) -> None:
        import psycopg
        from psycopg.types.json import Jsonb

        try:
            with psycopg.connect(self.dsn) as connection:
                connection.execute(
                    """
                    INSERT INTO mafia_economy_state (state_key, payload)
                    VALUES (%s, %s)
                    ON CONFLICT (state_key)
                    DO UPDATE SET payload = EXCLUDED.payload, updated_at = now()
                    """,
                    (self.state_key, Jsonb(self._snapshot())),
                )
        except Exception as exc:
            raise RuntimeError(
                "Could not save player data to PostgreSQL."
            ) from exc

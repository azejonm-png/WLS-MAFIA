# WLS MAFIA Telegram bot

Guruhga botni qo‘shing va o‘yinchilar avval botning shaxsiy chatida `/start`
yuborsin. Bu rollar guruhga oshkor bo‘lmasdan yetkazilishi uchun kerak.

1. Guruhda `/mafia` yuborib kutish xonasini oching.
2. Ishtirokchilar `/join` buyrug‘i yoki tugma orqali qo‘shiladi.
3. Kamida 5 kishi bo‘lgach `/startgame` yuboring.
4. Maxsus rollar bot bilan shaxsiy chatda harakat qiladi. Tunda yakunlangach
   muhokama va ovoz berish avtomatik boshlanadi.
5. Mafiya tirik aholi soniga tenglashganda yoki barcha mafiyalar chiqarilganda
   o‘yin avtomatik yakunlanadi.

## Profil va o‘yin do‘koni

Botning shaxsiy chatida:

- `/profile` — balans, VIP holati, statistikalar va taqilgan nishon
- `/shop` — 30 kunlik VIP yoki profil nishonlarini o‘yin valyutasiga olish
- `/inventory` — olingan nishonlarni ko‘rish, taqish yoki yechish

Yangi profil $500 va 2 diamond bilan boshlanadi. Har bir yakunlangan o‘yin
ishtirokchiga $100 beradi; g‘olib jamoa a’zolari yana $250 va 1 diamond oladi.
VIP dollar mukofotlarini ikki baravar qiladi. Valyutalar faqat o‘yin ichida
ishlatiladi; pul o‘tkazish yoki haqiqiy to‘lov mavjud emas.

VIP 30 kunlik bo‘lib, $1,500 yoki 8 diamond turadi. Nishonlar $350–$500
oralig‘ida. Profil va balanslar `data/economy.json` faylida, faol o‘yinlar esa
`data/games.json` faylida saqlanadi. Fayllar bot qayta ishga tushganda saqlanib
qoladi; ularni muntazam zaxiralab turing.

"""Telegram polling app and Uzbek-language group game flow."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from collections.abc import Iterable
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    Update,
)
from telegram.error import TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
)

from bot.game import Game, MIN_PLAYERS, Phase, Player, Role, Team
from bot.economy import (
    PostgresEconomyStore,
    PlayerProfile,
    SHOP_CATEGORIES,
    SHOP_ITEMS,
)
from bot.store import GameStore

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logging.getLogger("httpx").disabled = True
logging.getLogger("httpcore").disabled = True
logger = logging.getLogger("mafia_uzbek")

NIGHT_SECONDS = 60
DISCUSSION_SECONDS = 60
VOTING_SECONDS = 45
TICK_SECONDS = 2

ROLE_NAMES = {
    Role.MAFIA: "Mafiya",
    Role.DOCTOR: "Shifokor",
    Role.DETECTIVE: "Komissar",
    Role.CITIZEN: "Tinch aholi",
}

store = GameStore()
economy_store = PostgresEconomyStore()

BADGE_NAMES = {
    "badge_detective": "Komissar nishoni",
    "badge_mafia": "Mafiya nishoni",
    "badge_city": "Shahar posboni nishoni",
}
ITEM_NAMES = {
    **BADGE_NAMES,
    "night_shield": "Tungi qalqon",
    "chest_basic": "Oddiy sandiq",
    "chest_rare": "Noyob sandiq",
}


def is_group(update: Update) -> bool:
    chat = update.effective_chat
    return chat is not None and chat.type in {"group", "supergroup"}


def get_player(update: Update) -> Player | None:
    user = update.effective_user
    if user is None:
        return None
    profile = economy_store.ensure_profile(
        user_id=user.id,
        name=user.full_name,
        username=user.username,
    )
    return Player(
        user_id=user.id,
        name=user.full_name,
        username=user.username,
        badge=profile.active_badge,
    )


def display_player(player: Player) -> str:
    return f"@{player.username}" if player.username else player.name


def format_lobby(game: Game) -> str:
    names = "\n".join(
        f"{index}. {player.name}"
        f"{' · ' + BADGE_NAMES[player.badge] if player.badge in BADGE_NAMES else ''}"
        for index, player in enumerate(game.players.values(), start=1)
    )
    if not names:
        names = "Hali hech kim qo‘shilmadi."
    return (
        f"WLS MAFIA — {game.group_title}\n\n"
        f"Kutish xonasi: {len(game.players)} ishtirokchi\n"
        f"Boshlash uchun kamida {MIN_PLAYERS} kishi kerak.\n\n"
        f"{names}\n\n"
        "Botga shaxsiy xabarda /start yuboring. O‘yin boshlanganda rollar "
        "shaxsiy xabarda beriladi."
    )


def lobby_keyboard(game: Game) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "O‘yinga qo‘shilish",
                    callback_data=f"join:{game.group_id}",
                ),
                InlineKeyboardButton(
                    "Boshlash",
                    callback_data=f"start:{game.group_id}",
                ),
            ]
        ]
    )


def target_keyboard(
    game: Game, actor: Player, action: str
) -> InlineKeyboardMarkup | None:
    candidates: Iterable[Player] = (
        player for player in game.living_players if player.user_id != actor.user_id
    )
    if action == "mafia":
        candidates = (
            player for player in candidates if player.role != Role.MAFIA
        )
    buttons = [
        [
            InlineKeyboardButton(
                player.name,
                callback_data=f"act:{game.group_id}:{action}:{player.user_id}",
            )
        ]
        for player in candidates
    ]
    return InlineKeyboardMarkup(buttons) if buttons else None


def vote_keyboard(game: Game) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    player.name,
                    callback_data=f"vote:{game.group_id}:{player.user_id}",
                )
            ]
            for player in game.living_players
        ]
    )


def group_id_from_callback(update: Update) -> int | None:
    if update.callback_query and update.callback_query.message:
        return update.callback_query.message.chat.id
    return update.effective_chat.id if update.effective_chat else None


async def safe_send(
    context: ContextTypes.DEFAULT_TYPE, chat_id: int, text: str, **kwargs: object
) -> Message | None:
    try:
        return await context.bot.send_message(chat_id=chat_id, text=text, **kwargs)
    except TelegramError as exc:
        logger.warning(
            "Could not send a Telegram message to chat %s (%s)",
            chat_id,
            type(exc).__name__,
        )
        return None


async def refresh_lobby(
    context: ContextTypes.DEFAULT_TYPE, game: Game
) -> None:
    if game.lobby_message_id is None:
        return
    try:
        await context.bot.edit_message_text(
            chat_id=game.group_id,
            message_id=game.lobby_message_id,
            text=format_lobby(game),
            reply_markup=lobby_keyboard(game),
        )
    except TelegramError as exc:
        logger.warning(
            "Could not update the lobby message for %s (%s)",
            game.group_id,
            type(exc).__name__,
        )


async def start_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    chat = update.effective_chat
    if chat is None:
        return
    if chat.type == "private":
        player = get_player(update)
        profile = economy_store.get_profile(player.user_id) if player else None
        await safe_send(
            context,
            chat.id,
            private_start_message(profile),
            reply_markup=home_keyboard(),
        )
    else:
        await safe_send(
            context,
            chat.id,
            "Yangi o‘yin uchun /mafia, kutish xonasiga kirish uchun /join, "
            "boshlash uchun /startgame buyrug‘idan foydalaning.",
        )


async def create_game(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not is_group(update):
        await safe_send(
            context,
            update.effective_chat.id if update.effective_chat else 0,
            "O‘yin guruhda boshlanadi. Botni guruhga qo‘shib, /mafia yuboring.",
        )
        return

    chat = update.effective_chat
    creator = get_player(update)
    if chat is None or creator is None:
        return
    existing = store.get(chat.id)
    if existing is not None and existing.phase != Phase.FINISHED:
        await safe_send(
            context,
            chat.id,
            "Bu guruhda o‘yin allaqachon ochilgan. "
            "Kutish xonasiga kirish uchun /join yuboring.",
        )
        return

    game = Game(
        group_id=chat.id,
        group_title=chat.title or "Guruh",
        creator_id=creator.user_id,
    )
    store.put(game)
    message = await safe_send(
        context,
        chat.id,
        format_lobby(game),
        reply_markup=lobby_keyboard(game),
    )
    if message:
        game.lobby_message_id = message.message_id
        store.put(game)


async def join_lobby(
    update: Update, context: ContextTypes.DEFAULT_TYPE, group_id: int | None = None
) -> None:
    player = get_player(update)
    chat_id = group_id or (
        update.effective_chat.id if update.effective_chat else None
    )
    if player is None or chat_id is None:
        return
    game = store.get(chat_id)
    if game is None or game.phase != Phase.LOBBY:
        await safe_send(context, chat_id, "Hozir ochiq kutish xonasi yo‘q. /mafia yuboring.")
        return

    result = game.add_player(player)
    store.put(game)
    if result == "joined":
        await safe_send(context, chat_id, f"{player.name} o‘yinga qo‘shildi.")
        await refresh_lobby(context, game)
    elif result == "already_joined":
        await safe_send(context, chat_id, "Siz allaqachon kutish xonasidasiz.")
    else:
        await safe_send(context, chat_id, "Kutish xonasi yopilgan.")


async def join_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not is_group(update):
        await safe_send(context, update.effective_chat.id if update.effective_chat else 0, "O‘yinga faqat guruhda qo‘shilish mumkin.")
        return
    await join_lobby(update, context)


async def start_game(
    update: Update, context: ContextTypes.DEFAULT_TYPE, group_id: int | None = None
) -> None:
    chat_id = group_id or (
        update.effective_chat.id if update.effective_chat else None
    )
    if chat_id is None:
        return
    game = store.get(chat_id)
    if game is None or game.phase != Phase.LOBBY:
        await safe_send(context, chat_id, "Boshlash uchun ochiq kutish xonasi yo‘q.")
        return
    if len(game.players) < MIN_PLAYERS:
        await safe_send(
            context,
            chat_id,
            f"O‘yinni boshlash uchun kamida {MIN_PLAYERS} ishtirokchi kerak. "
            f"Hozir: {len(game.players)}.",
        )
        return

    ready_messages: dict[int, Message] = {}
    unavailable: list[Player] = []
    for player in game.players.values():
        message = await safe_send(
            context,
            player.user_id,
            "WLS MAFIA o‘yini boshlanmoqda. Shaxsiy chat faol, rol tayyorlanmoqda.",
        )
        if message is None:
            unavailable.append(player)
        else:
            ready_messages[player.user_id] = message

    if unavailable:
        missing = ", ".join(display_player(player) for player in unavailable)
        await safe_send(
            context,
            chat_id,
            "Rollarni xavfsiz yuborish uchun har bir ishtirokchi botga "
            "shaxsiy chatda /start yuborishi kerak. Hali tayyor emas: "
            f"{missing}. Ular /start yuborgach, /startgame ni qayta kiriting.",
        )
        return

    game.assign_roles()
    for player in game.players.values():
        player.protection_active = economy_store.consume_protection(player.user_id)
    game.begin_night(NIGHT_SECONDS)
    store.put(game)
    await safe_send(
        context,
        chat_id,
        "O‘yin boshlandi. Tun tushdi. Har bir maxsus rolga ega o‘yinchi "
        "botning shaxsiy chatida harakat tanlaydi. "
        f"Bosqich {NIGHT_SECONDS} soniyadan keyin avtomatik tugaydi.",
    )

    for player in game.players.values():
        role = player.role
        if role is None:
            continue
        if role == Role.MAFIA:
            partners = [
                other.name
                for other in game.living_mafia
                if other.user_id != player.user_id
            ]
            intro = "Sizning rolingiz: Mafiya. Shahar aholisini tunda nishonga oling."
            if partners:
                intro += f" Jamoadoshlaringiz: {', '.join(partners)}."
            keyboard = target_keyboard(game, player, "mafia")
        elif role == Role.DOCTOR:
            intro = "Sizning rolingiz: Shifokor. Tunda bir ishtirokchini himoya qiling."
            keyboard = target_keyboard(game, player, "doctor")
        elif role == Role.DETECTIVE:
            intro = "Sizning rolingiz: Komissar. Tunda bir ishtirokchini tekshiring."
            keyboard = target_keyboard(game, player, "detective")
        else:
            intro = "Sizning rolingiz: Tinch aholi. Kunduzi fikr bildiring va ovoz bering."
            keyboard = None

        ready_message = ready_messages[player.user_id]
        try:
            await context.bot.edit_message_text(
                chat_id=player.user_id,
                message_id=ready_message.message_id,
                text=intro,
                reply_markup=keyboard,
            )
        except TelegramError as exc:
            logger.warning(
                "Could not deliver a role to player %s (%s)",
                player.user_id,
                type(exc).__name__,
            )

    if game.night_actions_complete():
        await resolve_night_phase(context.application, game)


async def start_game_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not is_group(update):
        await safe_send(context, update.effective_chat.id if update.effective_chat else 0, "O‘yinni guruhda boshlang.")
        return
    await start_game(update, context)


async def night_action(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    group_id: int,
    action: str,
    target_id: int,
) -> None:
    query = update.callback_query
    actor = update.effective_user
    if query is None or actor is None:
        return
    game = store.get(group_id)
    if game is None:
        await query.answer("O‘yin topilmadi.", show_alert=True)
        return
    result = game.set_night_action(actor.id, action, target_id)
    if result != "saved":
        messages = {
            "wrong_phase": "Tun bosqichi tugagan.",
            "not_alive": "Faqat tirik ishtirokchilar harakat qilishi mumkin.",
            "self_target": "O‘zingizni tanlay olmaysiz.",
            "invalid_target": "Bu nishonni tanlab bo‘lmaydi.",
            "wrong_role": "Bu harakat sizning rolingizga mos emas.",
        }
        await query.answer(messages.get(result, "Harakat qabul qilinmadi."), show_alert=True)
        return

    store.put(game)
    if action == "detective":
        target = game.players[target_id]
        identity = "Mafiya" if target.role == Role.MAFIA else "Mafiya emas"
        await safe_send(
            context,
            actor.id,
            f"Tekshiruv natijasi: {target.name} — {identity}.",
        )
    await query.answer("Tanlovingiz saqlandi.")
    if game.night_actions_complete():
        await resolve_night_phase(context.application, game)


async def day_vote(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    group_id: int,
    target_id: int,
) -> None:
    query = update.callback_query
    voter = update.effective_user
    if query is None or voter is None:
        return
    game = store.get(group_id)
    if game is None:
        await query.answer("O‘yin topilmadi.", show_alert=True)
        return
    result = game.cast_day_vote(voter.id, target_id)
    if result != "saved":
        messages = {
            "wrong_phase": "Ovoz berish yakunlangan.",
            "not_alive": "Faqat tirik ishtirokchilar ovoz beradi.",
            "self_target": "O‘zingizga ovoz bera olmaysiz.",
        }
        await query.answer(messages.get(result, "Ovoz qabul qilinmadi."), show_alert=True)
        return

    store.put(game)
    await query.answer("Ovozingiz yashirin tarzda qabul qilindi.")
    if game.voting_complete():
        await resolve_vote_phase(context.application, game)


async def callback_router(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    query = update.callback_query
    if query is None or not query.data:
        return
    parts = query.data.split(":")
    try:
        if parts[0] in {
            "buy",
            "equip",
            "shopcat",
            "chest",
            "protection",
            "daily",
            "menu",
        }:
            await economy_callback(update, context, parts)
        elif parts[0] == "join" and len(parts) == 2:
            await query.answer()
            await join_lobby(update, context, int(parts[1]))
        elif parts[0] == "start" and len(parts) == 2:
            await query.answer()
            await start_game(update, context, int(parts[1]))
        elif parts[0] == "act" and len(parts) == 4:
            await night_action(
                update, context, int(parts[1]), parts[2], int(parts[3])
            )
        elif parts[0] == "vote" and len(parts) == 3:
            await day_vote(update, context, int(parts[1]), int(parts[2]))
        else:
            await query.answer("Bu tugma eskirgan.", show_alert=True)
    except ValueError:
        await query.answer("Tugma ma’lumotini o‘qib bo‘lmadi.", show_alert=True)


async def resolve_night_phase(
    application: Application, game: Game
) -> None:
    if game.phase != Phase.NIGHT:
        return
    eliminated, saved, tied, shield_saved = game.resolve_night()
    winner = game.winner()
    if winner:
        game.finish()
    else:
        game.begin_discussion(DISCUSSION_SECONDS)
    store.put(game)

    if shield_saved:
        result = "Tong otdi. Tungi qalqon mafiya hujumidan himoya qildi."
    elif eliminated:
        result = (
            f"Tong otdi. {eliminated.name} tunda o‘yindan chiqdi. "
            f"Uning roli: {ROLE_NAMES[eliminated.role]}."
        )
    elif saved:
        result = "Tong otdi. Shifokor nishonni saqlab qoldi; hech kim o‘yindan chiqmadi."
    elif tied:
        result = "Tong otdi. Mafiya ovozlari teng bo‘ldi; hech kim nishonga olinmadi."
    else:
        result = "Tong otdi. Bu tunda hech kim o‘yindan chiqmadi."
    await safe_send(application, game.group_id, result)
    if winner:
        await announce_winner(application, game, winner)
        return
    await safe_send(
        application,
        game.group_id,
        f"Kunduzgi muhokama boshlandi. "
        f"{DISCUSSION_SECONDS} soniyadan keyin ovoz berish avtomatik ochiladi.",
    )


async def open_voting_phase(
    application: Application, game: Game
) -> None:
    if game.phase != Phase.DISCUSSION:
        return
    game.begin_voting(VOTING_SECONDS)
    store.put(game)
    if len(game.living_players) < 2:
        await resolve_vote_phase(application, game)
        return
    await safe_send(
        application,
        game.group_id,
        f"Ovoz berish boshlandi. Ishtirokchini tanlang. "
        f"{VOTING_SECONDS} soniyadan keyin natija avtomatik hisoblanadi.",
        reply_markup=vote_keyboard(game),
    )


async def resolve_vote_phase(
    application: Application, game: Game
) -> None:
    if game.phase != Phase.VOTING:
        return
    eliminated, tied = game.resolve_day_vote()
    winner = game.winner()
    if winner:
        game.finish()
    else:
        game.round_number += 1
        game.begin_night(NIGHT_SECONDS)
    store.put(game)

    if eliminated:
        result = (
            f"Ovoz natijasi: {eliminated.name} o‘yindan chiqdi. "
            f"Uning roli: {ROLE_NAMES[eliminated.role]}."
        )
    elif tied:
        result = "Ovozlar teng bo‘ldi. Hech kim o‘yindan chiqmadi."
    else:
        result = "Ovoz berishda natija bo‘lmadi. Hech kim o‘yindan chiqmadi."
    await safe_send(application, game.group_id, result)
    if winner:
        await announce_winner(application, game, winner)
        return
    await open_night_phase(application, game)


async def open_night_phase(application: Application, game: Game) -> None:
    await safe_send(
        application,
        game.group_id,
        f"{game.round_number}-tun boshlandi. Maxsus rollar botning shaxsiy "
        f"chatida harakat qiladi; bosqich {NIGHT_SECONDS} soniyadan keyin tugaydi.",
    )
    for player in game.living_players:
        if player.role not in {Role.MAFIA, Role.DOCTOR, Role.DETECTIVE}:
            continue
        action = {
            Role.MAFIA: "mafia",
            Role.DOCTOR: "doctor",
            Role.DETECTIVE: "detective",
        }[player.role]
        intro = {
            Role.MAFIA: "Tungi ovozingizni tanlang.",
            Role.DOCTOR: "Bu tunda kimni himoya qilasiz?",
            Role.DETECTIVE: "Bu tunda kimni tekshirasiz?",
        }[player.role]
        await safe_send(
            application,
            player.user_id,
            intro,
            reply_markup=target_keyboard(game, player, action),
        )
    if game.night_actions_complete():
        await resolve_night_phase(application, game)


async def announce_winner(
    application: Application, game: Game, winner: Team
) -> None:
    await announce_economy_rewards(application, game, winner)
    team_name = (
        "Tinch aholi" if winner == Team.TOWNSPEOPLE else "Mafiya"
    )
    roles = "\n".join(
        f"{player.name} — {ROLE_NAMES[player.role]}"
        for player in game.players.values()
        if player.role is not None
    )
    await safe_send(
        application,
        game.group_id,
        f"O‘yin yakunlandi. G‘oliblar: {team_name}.\n\nRollar:\n{roles}",
    )


async def status_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not is_group(update):
        await safe_send(context, update.effective_chat.id if update.effective_chat else 0, "Holatni guruhda ko‘rish mumkin.")
        return
    chat = update.effective_chat
    if chat is None:
        return
    game = store.get(chat.id)
    if game is None:
        await safe_send(context, chat.id, "Bu guruhda hozircha o‘yin yo‘q. /mafia yuboring.")
        return
    phase_names = {
        Phase.LOBBY: "Kutish xonasi",
        Phase.NIGHT: "Tun",
        Phase.DISCUSSION: "Muhokama",
        Phase.VOTING: "Ovoz berish",
        Phase.FINISHED: "Yakunlandi",
    }
    await safe_send(
        context,
        chat.id,
        f"O‘yin holati: {phase_names[game.phase]}\n"
        f"Bosqich: {game.round_number}\n"
        f"Tirik ishtirokchilar: {len(game.living_players)} / {len(game.players)}",
    )


def private_start_message(profile: PlayerProfile | None) -> str:
    welcome = (
        "🔥 WLS MAFIA botiga xush kelibsiz!\n\n"
        "🎭 Mafia o‘yiniga qo‘shiling.\n"
        "Guruhda /mafia buyrug‘i orqali yangi o‘yin boshlang.\n"
        "Rolingizni olish uchun avval shu shaxsiy chatda /start bosing."
    )
    if profile is None:
        return welcome
    return (
        f"{welcome}\n\n"
        "Profil va do‘kon: /profile, /shop, /inventory, /daily.\n"
        f"Boshlang‘ich balans: ${profile.dollars:,} va 💎 {profile.diamonds}.\n"
        "Dollar va diamond — faqat o‘yin ichidagi valyuta, haqiqiy pul emas."
    )


def home_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("👤 Profilim", callback_data="menu:profile"),
                InlineKeyboardButton("🛍 Do‘kon", callback_data="menu:shop"),
            ],
            [
                InlineKeyboardButton("🎒 Inventar", callback_data="menu:inventory"),
                InlineKeyboardButton("🎁 Kunlik bonus", callback_data="daily:claim"),
            ],
        ]
    )


def format_profile(profile: PlayerProfile) -> str:
    now = time.time()
    premium_days = max(0, int((profile.premium_until - now + 86399) // 86400))
    vip_days = max(0, int((profile.vip_until - now + 86399) // 86400))
    if premium_days:
        membership = f"Premium — yana {premium_days} kun"
    elif vip_days:
        membership = f"VIP — yana {vip_days} kun"
    else:
        membership = "Faol a’zolik yo‘q"
    badge = BADGE_NAMES.get(profile.active_badge or "", "Yo‘q")
    username = f"@{profile.username}" if profile.username else profile.name
    win_rate = round(profile.wins / profile.games_played * 100) if profile.games_played else 0
    shield_status = "Keyingi o‘yinga tayyor" if profile.protection_ready else "Yo‘q"
    return (
        f"👤 WLS MAFIA PROFILI — {username}\n\n"
        f"💵 Dollar: ${profile.dollars:,}  |  💎 Diamond: {profile.diamonds}\n"
        f"👑 A’zolik: {membership}\n"
        f"🏷 Faol nishon: {badge}\n"
        f"🛡 Himoya: {shield_status}\n"
        f"🎮 O‘yinlar: {profile.games_played}  |  🏆 G‘alabalar: {profile.wins} ({win_rate}%)\n"
        f"🧾 Saqlangan amallar: {len(profile.purchase_history)}\n\n"
        "Barcha balanslar virtual o‘yin valyutasidir."
    )


def format_shop(
    profile: PlayerProfile,
    category: str | None = None,
    notice: str | None = None,
) -> str:
    lines = [
        "🛍 WLS MAFIA — DO‘KON",
        f"💵 ${profile.dollars:,}  |  💎 {profile.diamonds}",
        "",
    ]
    if category is None:
        lines.extend(
            [
                "Kerakli bo‘limni tanlang:",
                "VIP va Premium mukofotlarni ko‘paytiradi.",
                "Himoya va sandiqlar inventarda saqlanadi.",
            ]
        )
    else:
        category_items = [
            item for item in SHOP_ITEMS.values() if item.category == category
        ]
        lines.append(SHOP_CATEGORIES.get(category, "Do‘kon"))
        for item in category_items:
            lines.extend(["", f"{item.name}", item.description])
            prices = []
            if item.dollar_price is not None:
                prices.append(f"${item.dollar_price:,}".replace(",", " "))
            if item.diamond_price is not None:
                prices.append(f"{item.diamond_price} 💎")
            if prices:
                lines.append("Narxi: " + " yoki ".join(prices))
    lines.extend(["", "Valyutalar virtual; haqiqiy to‘lov ishlatilmaydi."])
    if notice:
        lines.insert(0, notice)
        lines.insert(1, "")
    return "\n".join(lines)


def shop_keyboard(category: str | None = None) -> InlineKeyboardMarkup:
    if category is None:
        buttons = [
            [
                InlineKeyboardButton(
                    label,
                    callback_data=f"shopcat:{category_id}",
                )
            ]
            for category_id, label in SHOP_CATEGORIES.items()
        ]
        buttons.extend(
            [
                [
                    InlineKeyboardButton(
                        "👤 Profilim", callback_data="menu:profile"
                    ),
                    InlineKeyboardButton(
                        "🎁 Kunlik bonus", callback_data="daily:claim"
                    ),
                ]
            ]
        )
        return InlineKeyboardMarkup(buttons)

    buttons: list[list[InlineKeyboardButton]] = []
    for item_id, item in SHOP_ITEMS.items():
        if item.category != category:
            continue
        row: list[InlineKeyboardButton] = []
        if item.dollar_price is not None:
            row.append(
                InlineKeyboardButton(
                    f"🛒 ${item.dollar_price:,}".replace(",", " "),
                    callback_data=f"buy:{item_id}:dollars",
                )
            )
        if item.diamond_price is not None:
            row.append(
                InlineKeyboardButton(
                    f"💎 {item.diamond_price}",
                    callback_data=f"buy:{item_id}:diamonds",
                )
            )
        if row:
            buttons.append(row)
    buttons.extend(
        [
            [InlineKeyboardButton("⬅️ Bo‘limlar", callback_data="menu:shop")],
            [
                InlineKeyboardButton(
                    "🎒 Inventar", callback_data="menu:inventory"
                ),
                InlineKeyboardButton("👤 Profil", callback_data="menu:profile"),
            ],
        ]
    )
    return InlineKeyboardMarkup(buttons)


def format_inventory(profile: PlayerProfile, notice: str | None = None) -> str:
    lines = ["🎒 WLS MAFIA — INVENTAR"]
    if notice:
        lines.extend([notice, ""])
    if profile.inventory:
        for item_id, count in profile.inventory.items():
            item_name = ITEM_NAMES.get(item_id, item_id)
            if item_id in BADGE_NAMES and profile.active_badge == item_id:
                lines.append(f"🏷 {item_name} ×{count} — taqilgan")
            else:
                lines.append(f"• {item_name} ×{count}")
        lines.extend(["", "Buyum yonidagi tugma orqali ishlating yoki taqing."])
    else:
        lines.append("Inventaringiz hozircha bo‘sh. Buyumlarni /shop orqali oling.")
    if profile.active_badge:
        lines.append(
            f"\nHozir taqilgan: {BADGE_NAMES.get(profile.active_badge, 'Nishon')}"
        )
    lines.append(
        "\nTungi qalqon faollashtirilsa, keyingi o‘yinda bir hujumni to‘sadi."
    )
    if profile.protection_ready:
        lines.append("🛡 Qalqon keyingi o‘yin uchun tayyor.")
    return "\n".join(lines)


def inventory_keyboard(profile: PlayerProfile) -> InlineKeyboardMarkup | None:
    if not profile.inventory and not profile.active_badge and not profile.protection_ready:
        return None
    buttons: list[list[InlineKeyboardButton]] = []
    for item_id, count in profile.inventory.items():
        if item_id in BADGE_NAMES:
            buttons.append(
                [
                    InlineKeyboardButton(
                        f"🏷 Taqish: {BADGE_NAMES[item_id]}",
                        callback_data=f"equip:{item_id}",
                    )
                ]
            )
        elif item_id.startswith("chest_") and count > 0:
            buttons.append(
                [
                    InlineKeyboardButton(
                        f"🎁 Ochish: {ITEM_NAMES.get(item_id, item_id)} ×{count}",
                        callback_data=f"chest:open:{item_id}",
                    )
                ]
            )
        elif item_id == "night_shield" and count > 0 and not profile.protection_ready:
            buttons.append(
                [
                    InlineKeyboardButton(
                        "🛡 Qalqonni keyingi o‘yinga faollashtirish",
                        callback_data="protection:activate",
                    )
                ]
            )
    if profile.protection_ready:
        buttons.append(
            [
                InlineKeyboardButton(
                    "↩️ Qalqonni inventarga qaytarish",
                    callback_data="protection:cancel",
                )
            ]
        )
    if profile.active_badge:
        buttons.append(
            [InlineKeyboardButton("🏷 Nishonni yechish", callback_data="equip:none")]
        )
    buttons.append(
        [
            InlineKeyboardButton("🛍 Do‘kon", callback_data="menu:shop"),
            InlineKeyboardButton("👤 Profil", callback_data="menu:profile"),
        ]
    )
    return InlineKeyboardMarkup(buttons)


def daily_claim_response(
    user_id: int,
    name: str,
    username: str | None,
) -> tuple[str, PlayerProfile]:
    day_key = datetime.now(ZoneInfo("Asia/Tashkent")).date().isoformat()
    status, reward = economy_store.claim_daily(
        user_id,
        name,
        username,
        day_key,
    )
    profile = economy_store.get_profile(user_id)
    if profile is None:
        raise RuntimeError("Daily reward profile was not saved.")
    if status == "claimed" and reward:
        text = (
            f"🎁 Kunlik bonus olindi!\n"
            f"+${reward['dollars']:,} va +💎 {reward['diamonds']}.\n"
            f"Balans: ${profile.dollars:,}  |  💎 {profile.diamonds}\n"
            "Keyingi bonus Toshkent vaqti bilan ertaga ochiladi."
        )
    else:
        text = "✅ Bugungi kunlik bonusni olib bo‘ldingiz. Ertaga qayting."
    return text, profile


async def private_economy_command(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    view: str,
) -> None:
    chat = update.effective_chat
    player = get_player(update)
    if chat is None or player is None:
        return
    if chat.type != "private":
        await safe_send(
            context,
            chat.id,
            "Profil, do‘kon va inventar balansingizni himoya qilish uchun "
            "botning shaxsiy chatida ishlaydi.",
        )
        return

    profile = economy_store.get_profile(player.user_id)
    if profile is None:
        return
    if view == "profile":
        await safe_send(
            context,
            chat.id,
            format_profile(profile),
            reply_markup=home_keyboard(),
        )
    elif view == "shop":
        await safe_send(
            context,
            chat.id,
            format_shop(profile),
            reply_markup=shop_keyboard(),
        )
    else:
        await safe_send(
            context,
            chat.id,
            format_inventory(profile),
            reply_markup=inventory_keyboard(profile),
        )
    elif view == "daily":
        text, _ = daily_claim_response(
            player.user_id,
            player.name,
            player.username,
        )
        await safe_send(
            context,
            chat.id,
            text,
            reply_markup=home_keyboard(),
        )


async def profile_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    await private_economy_command(update, context, "profile")


async def shop_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    await private_economy_command(update, context, "shop")


async def inventory_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    await private_economy_command(update, context, "inventory")


async def daily_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    await private_economy_command(update, context, "daily")


async def economy_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, parts: list[str]
) -> None:
    query = update.callback_query
    actor = update.effective_user
    if query is None or actor is None:
        return
    if query.message is None or query.message.chat.type != "private":
        await query.answer("Bu bo‘lim botning shaxsiy chatida ishlaydi.", show_alert=True)
        return

    profile = economy_store.ensure_profile(
        actor.id, actor.full_name, actor.username
    )
    action = parts[0]

    if action == "menu" and len(parts) == 2:
        view = parts[1]
        if view == "profile":
            text, keyboard = format_profile(profile), home_keyboard()
        elif view == "shop":
            text, keyboard = format_shop(profile), shop_keyboard()
        elif view == "inventory":
            text = format_inventory(profile)
            keyboard = inventory_keyboard(profile) or home_keyboard()
        elif view == "daily":
            text, profile = daily_claim_response(
                actor.id, actor.full_name, actor.username
            )
            keyboard = home_keyboard()
        else:
            await query.answer("Bo‘lim topilmadi.", show_alert=True)
            return
        await query.answer()
        await _edit_economy_message(query, text, keyboard)
        return

    if action == "shopcat" and len(parts) == 2:
        category = parts[1]
        if category not in SHOP_CATEGORIES:
            await query.answer("Do‘kon bo‘limi topilmadi.", show_alert=True)
            return
        await query.answer()
        await _edit_economy_message(
            query,
            format_shop(profile, category),
            shop_keyboard(category),
        )
        return

    if action == "buy" and len(parts) == 3:
        result = economy_store.purchase(
            actor.id,
            actor.full_name,
            actor.username,
            parts[1],
            parts[2],
        )
        messages = {
            "purchased": "Xarid muvaffaqiyatli.",
            "insufficient_funds": "Balansingiz yetarli emas.",
            "already_owned": "Bu buyum inventaringizda bor.",
            "invalid_currency": "Bu valyutada xarid qilib bo‘lmaydi.",
            "not_found": "Do‘kon buyumi topilmadi.",
        }
        await query.answer(
            messages.get(result, "Xarid amalga oshmadi."),
            show_alert=result != "purchased",
        )
        if result == "purchased":
            profile = economy_store.get_profile(actor.id) or profile
        item = SHOP_ITEMS.get(parts[1])
        category = item.category if item else None
        await _edit_economy_message(
            query,
            format_shop(profile, category, messages.get(result)),
            shop_keyboard(category),
        )
        return

    if action == "equip" and len(parts) == 2:
        item_id = None if parts[1] == "none" else parts[1]
        result = economy_store.equip_badge(actor.id, item_id)
        messages = {
            "equipped": "Nishon profilingizga taqildi.",
            "unequipped": "Nishon yechildi.",
            "not_owned": "Bu nishon inventaringizda yo‘q.",
            "profile_missing": "Profil topilmadi.",
        }
        await query.answer(
            messages.get(result, "Amal bajarilmadi."),
            show_alert=result not in {"equipped", "unequipped"},
        )
        profile = economy_store.get_profile(actor.id) or profile
        await _edit_economy_message(
            query,
            format_inventory(profile, messages.get(result)),
            inventory_keyboard(profile) or home_keyboard(),
        )
        return

    if action == "chest" and len(parts) == 3 and parts[1] == "open":
        result, reward = economy_store.open_chest(actor.id, parts[2])
        if result == "opened" and reward:
            await query.answer("Sandiq ochildi!")
            profile = economy_store.get_profile(actor.id) or profile
            notice = f"🎉 Sandiqdan chiqdi: {reward['label']}."
        else:
            await query.answer("Bu sanduq inventaringizda yo‘q.", show_alert=True)
            notice = "Sandiqni ochib bo‘lmadi."
        await _edit_economy_message(
            query,
            format_inventory(profile, notice),
            inventory_keyboard(profile) or home_keyboard(),
        )
        return

    if action == "protection" and len(parts) == 2:
        if parts[1] == "activate":
            result = economy_store.activate_protection(actor.id)
            messages = {
                "activated": "Qalqon keyingi o‘yinga faollashtirildi.",
                "already_active": "Qalqon allaqachon tayyor.",
                "not_owned": "Inventaringizda qalqon yo‘q.",
                "profile_missing": "Profil topilmadi.",
            }
        elif parts[1] == "cancel":
            result = economy_store.cancel_protection(actor.id)
            messages = {
                "cancelled": "Qalqon inventarga qaytarildi.",
                "not_active": "Faol qalqon topilmadi.",
                "profile_missing": "Profil topilmadi.",
            }
        else:
            await query.answer("Bu himoya amali tanilmadi.", show_alert=True)
            return
        await query.answer(
            messages.get(result, "Amal bajarilmadi."),
            show_alert=result not in {"activated", "cancelled"},
        )
        profile = economy_store.get_profile(actor.id) or profile
        await _edit_economy_message(
            query,
            format_inventory(profile, messages.get(result)),
            inventory_keyboard(profile) or home_keyboard(),
        )
        return

    if action == "daily" and len(parts) == 2 and parts[1] == "claim":
        text, profile = daily_claim_response(
            actor.id, actor.full_name, actor.username
        )
        await query.answer("Kunlik bonus tekshirildi.")
        await _edit_economy_message(query, text, home_keyboard())
        return

    await query.answer("Bu tugma eskirgan.", show_alert=True)


async def _edit_economy_message(
    query: object,
    text: str,
    keyboard: InlineKeyboardMarkup,
) -> None:
    try:
        await query.edit_message_text(text, reply_markup=keyboard)
    except TelegramError as exc:
        logger.warning(
            "Could not update a private economy message (%s)",
            type(exc).__name__,
        )


async def announce_economy_rewards(
    application: Application, game: Game, winner: Team
) -> None:
    winner_key = "mafia" if winner == Team.MAFIA else "townspeople"
    rewards = economy_store.settle_game(
        game_id=game.game_id,
        players=game.players.values(),
        winning_team=winner_key,
    )
    for user_id, reward in rewards.items():
        profile = economy_store.get_profile(user_id)
        if profile is None:
            continue
        win_note = "G‘alaba bonusi qo‘shildi." if reward["won"] else "Ishtirok bonusi qo‘shildi."
        await safe_send(
            application,
            user_id,
            f"O‘yin mukofoti: +${reward['dollars']:,} va "
            f"+💎 {reward['diamonds']}.\n"
            f"{win_note}\n"
            f"Yangi balans: ${profile.dollars:,}  |  💎 {profile.diamonds}",
        )


async def phase_clock(application: Application) -> None:
    while True:
        now = time.time()
        for game in list(store.games.values()):
            if game.deadline is None or now < game.deadline:
                continue
            if game.phase == Phase.NIGHT:
                await resolve_night_phase(application, game)
            elif game.phase == Phase.DISCUSSION:
                await open_voting_phase(application, game)
            elif game.phase == Phase.VOTING:
                await resolve_vote_phase(application, game)
        await asyncio.sleep(TICK_SECONDS)


async def post_init(application: Application) -> None:
    application.bot_data["phase_clock_task"] = asyncio.create_task(
        phase_clock(application)
    )
    me = await application.bot.get_me()
    logger.info("Telegram bot is running as @%s", me.username or me.id)


async def post_shutdown(application: Application) -> None:
    task = application.bot_data.get("phase_clock_task")
    if isinstance(task, asyncio.Task):
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


async def error_handler(
    update: object, context: ContextTypes.DEFAULT_TYPE
) -> None:
    error_name = type(context.error).__name__ if context.error else "unknown"
    logger.error("Unhandled Telegram update error (%s)", error_name)


def main() -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN is missing. Add it in Replit Secrets before starting the bot."
        )

    application = (
        Application.builder()
        .token(token)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("mafia", create_game))
    application.add_handler(CommandHandler("join", join_command))
    application.add_handler(CommandHandler("startgame", start_game_command))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("profile", profile_command))
    application.add_handler(CommandHandler("shop", shop_command))
    application.add_handler(CommandHandler("inventory", inventory_command))
    application.add_handler(CommandHandler("daily", daily_command))
    application.add_handler(CallbackQueryHandler(callback_router))
    application.add_error_handler(error_handler)
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()

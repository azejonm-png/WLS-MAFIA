"""Uzbek-language Telegram Mafia bot."""

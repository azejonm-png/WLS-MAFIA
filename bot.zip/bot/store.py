"""Small atomic JSON store for active group games."""

from __future__ import annotations

import json
import os
from pathlib import Path

from bot.game import Game


class GameStore:
    def __init__(self, data_dir: str | None = None) -> None:
        self.path = Path(data_dir or os.getenv("MAFIA_DATA_DIR", "data"))
        self.path = self.path / "games.json"
        self.games: dict[int, Game] = {}
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            self.games = {}
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("The saved game file must contain a JSON list.")
            self.games = {
                game.group_id: game for game in (Game.from_dict(item) for item in raw)
            }
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise RuntimeError(f"Could not load saved games from {self.path}.") from exc

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary_path = self.path.with_suffix(".json.tmp")
        payload = [game.to_dict() for game in self.games.values()]
        temporary_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        temporary_path.replace(self.path)

    def get(self, group_id: int) -> Game | None:
        return self.games.get(group_id)

    def put(self, game: Game) -> None:
        self.games[game.group_id] = game
        self.save()

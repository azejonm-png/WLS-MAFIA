"""Checks for persistent player profiles, purchases, and game settlements."""

from __future__ import annotations

import tempfile
import unittest

from bot.economy import (
    VIP_DURATION_SECONDS,
    EconomyStore,
)
from bot.game import Player, Role


class EconomyStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.store = EconomyStore(self.directory.name)

    def test_new_profile_and_balances_survive_reload(self) -> None:
        profile = self.store.ensure_profile(42, "Aziza", "aziza")
        self.assertEqual(profile.dollars, 500)
        self.assertEqual(profile.diamonds, 2)

        restored = EconomyStore(self.directory.name).get_profile(42)
        self.assertIsNotNone(restored)
        self.assertEqual(restored.name, "Aziza")
        self.assertEqual(restored.username, "aziza")
        self.assertEqual(restored.dollars, 500)
        self.assertEqual(restored.diamonds, 2)

    def test_badge_purchase_inventory_and_equip(self) -> None:
        profile = self.store.ensure_profile(7, "Jasur")
        profile.dollars = 1000
        self.store.save()

        self.assertEqual(
            self.store.purchase(7, "Jasur", None, "badge_detective", "dollars"),
            "purchased",
        )
        self.assertEqual(
            self.store.purchase(7, "Jasur", None, "badge_detective", "dollars"),
            "already_owned",
        )
        self.assertEqual(self.store.equip_badge(7, "badge_detective"), "equipped")
        self.assertEqual(
            self.store.get_profile(7).active_badge,
            "badge_detective",
        )
        self.assertEqual(self.store.equip_badge(7, None), "unequipped")
        self.assertEqual(self.store.get_profile(7).active_badge, None)

    def test_vip_can_be_extended_with_dollars_or_diamonds(self) -> None:
        profile = self.store.ensure_profile(8, "Malika")
        profile.dollars = 2000
        profile.diamonds = 10
        self.store.save()

        self.assertEqual(
            self.store.purchase(8, "Malika", None, "vip30", "dollars", now=1000),
            "purchased",
        )
        first_expiry = 1000 + VIP_DURATION_SECONDS
        self.assertEqual(self.store.get_profile(8).vip_until, first_expiry)
        self.assertEqual(
            self.store.purchase(8, "Malika", None, "vip30", "diamonds", now=1200),
            "purchased",
        )
        self.assertEqual(
            self.store.get_profile(8).vip_until,
            first_expiry + VIP_DURATION_SECONDS,
        )

    def test_game_rewards_are_vip_adjusted_and_idempotent(self) -> None:
        mafia = Player(10, "Mafiya", role=Role.MAFIA)
        citizen = Player(11, "Shahar", role=Role.CITIZEN)
        profile = self.store.ensure_profile(10, "Mafiya")
        profile.vip_until = 2000
        self.store.save()

        rewards = self.store.settle_game(
            "finished-game", [mafia, citizen], "mafia", now=1000
        )
        self.assertEqual(rewards[10], {"dollars": 700, "diamonds": 1, "won": True})
        self.assertEqual(rewards[11], {"dollars": 100, "diamonds": 0, "won": False})
        self.assertEqual(self.store.get_profile(10).wins, 1)
        self.assertEqual(
            self.store.settle_game(
                "finished-game", [mafia, citizen], "mafia", now=1000
            ),
            {},
        )
        self.assertEqual(self.store.get_profile(10).dollars, 1200)
        self.assertEqual(self.store.get_profile(10).diamonds, 3)

        restored = EconomyStore(self.directory.name)
        self.assertIn("finished-game", restored.settled_games)
        self.assertEqual(restored.get_profile(10).dollars, 1200)

    def test_purchases_reject_invalid_currency_and_insufficient_balance(self) -> None:
        self.store.ensure_profile(15, "Nodira")
        self.assertEqual(
            self.store.purchase(15, "Nodira", None, "vip30", "diamonds"),
            "insufficient_funds",
        )
        self.assertEqual(
            self.store.purchase(15, "Nodira", None, "badge_city", "diamonds"),
            "invalid_currency",
        )
        self.assertEqual(
            self.store.purchase(15, "Nodira", None, "unknown", "dollars"),
            "not_found",
        )


if __name__ == "__main__":
    unittest.main()

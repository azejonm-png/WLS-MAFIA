"""Unit checks for role balance, phase actions, voting, and winner detection."""

from __future__ import annotations

import random
import tempfile
import unittest

from bot.game import Game, MIN_PLAYERS, Phase, Player, Role, Team
from bot.store import GameStore


def make_game(player_count: int = MIN_PLAYERS) -> Game:
    game = Game(group_id=-1001, group_title="Test", creator_id=1)
    for player_id in range(1, player_count + 1):
        game.add_player(Player(player_id, f"Player {player_id}"))
    return game


class GameRulesTests(unittest.TestCase):
    def test_role_assignment_and_private_action_completion(self) -> None:
        game = make_game(8)
        game.assign_roles(random.Random(4))
        game.begin_night(duration=60, now=100)

        roles = [player.role for player in game.players.values()]
        self.assertEqual(roles.count(Role.MAFIA), 2)
        self.assertEqual(roles.count(Role.DOCTOR), 1)
        self.assertEqual(roles.count(Role.DETECTIVE), 1)
        self.assertEqual(game.phase, Phase.NIGHT)
        self.assertFalse(game.night_actions_complete())

        mafia = next(player for player in game.living_players if player.role == Role.MAFIA)
        target = next(player for player in game.living_players if player.role != Role.MAFIA)
        doctor = next(player for player in game.living_players if player.role == Role.DOCTOR)
        detective = next(player for player in game.living_players if player.role == Role.DETECTIVE)
        second_mafia = next(
            player
            for player in game.living_players
            if player.role == Role.MAFIA and player.user_id != mafia.user_id
        )

        self.assertEqual(game.set_night_action(mafia.user_id, "mafia", target.user_id), "saved")
        self.assertFalse(game.night_actions_complete())
        self.assertEqual(game.set_night_action(second_mafia.user_id, "mafia", target.user_id), "saved")
        self.assertEqual(game.set_night_action(doctor.user_id, "doctor", target.user_id), "saved")
        self.assertEqual(game.set_night_action(detective.user_id, "detective", target.user_id), "saved")
        self.assertTrue(game.night_actions_complete())

        eliminated, saved, tied, shield_saved = game.resolve_night()
        self.assertIsNone(eliminated)
        self.assertTrue(saved)
        self.assertFalse(tied)
        self.assertFalse(shield_saved)

    def test_night_shield_blocks_one_attack_then_expires(self) -> None:
        game = make_game(5)
        game.assign_roles(random.Random(11))
        game.begin_night(now=100)
        mafia = next(player for player in game.players.values() if player.role == Role.MAFIA)
        target = next(player for player in game.players.values() if player.role != Role.MAFIA)
        target.protection_active = True
        game.mafia_votes[mafia.user_id] = target.user_id

        eliminated, doctor_saved, tied, shield_saved = game.resolve_night()

        self.assertIsNone(eliminated)
        self.assertFalse(doctor_saved)
        self.assertFalse(tied)
        self.assertTrue(shield_saved)
        self.assertTrue(target.alive)
        self.assertFalse(target.protection_active)

    def test_plurality_vote_eliminates_and_detects_town_win(self) -> None:
        game = make_game(5)
        game.assign_roles(random.Random(2))
        game.begin_night(now=100)
        game.begin_voting(now=200)
        mafia = next(player for player in game.players.values() if player.role == Role.MAFIA)
        civilians = [player for player in game.players.values() if player.role != Role.MAFIA]

        for voter in civilians:
            game.cast_day_vote(voter.user_id, mafia.user_id)
        eliminated, tied = game.resolve_day_vote()

        self.assertFalse(tied)
        self.assertEqual(eliminated.user_id, mafia.user_id)
        self.assertEqual(game.winner(), Team.TOWNSPEOPLE)

    def test_mafia_wins_when_they_reach_parity(self) -> None:
        game = make_game(5)
        game.assign_roles(random.Random(9))
        mafia = next(player for player in game.players.values() if player.role == Role.MAFIA)
        for player in game.players.values():
            if player.role != Role.MAFIA:
                player.alive = False
        self.assertEqual(game.winner(), Team.MAFIA)

    def test_tied_vote_does_not_eliminate(self) -> None:
        game = make_game(5)
        game.assign_roles(random.Random(3))
        game.begin_voting(now=200)
        targets = [player for player in game.players.values() if player.role != Role.MAFIA][:2]
        voters = [player for player in game.players.values() if player.user_id not in {item.user_id for item in targets}]
        game.cast_day_vote(voters[0].user_id, targets[0].user_id)
        game.cast_day_vote(voters[1].user_id, targets[1].user_id)

        eliminated, tied = game.resolve_day_vote()
        self.assertIsNone(eliminated)
        self.assertTrue(tied)

    def test_state_survives_json_round_trip(self) -> None:
        game = make_game(6)
        game.assign_roles(random.Random(1))
        game.begin_night(now=123)
        with tempfile.TemporaryDirectory() as directory:
            store = GameStore(directory)
            store.put(game)
            restored = GameStore(directory).get(game.group_id)

        self.assertIsNotNone(restored)
        self.assertEqual(restored.phase, Phase.NIGHT)
        self.assertEqual(restored.deadline, 183)
        self.assertEqual(restored.game_id, game.game_id)
        self.assertEqual(
            [player.role for player in restored.players.values()],
            [player.role for player in game.players.values()],
        )


if __name__ == "__main__":
    unittest.main()

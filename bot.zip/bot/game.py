"""Deterministic game rules for the Telegram Mafia bot."""

from __future__ import annotations

import random
import time
from uuid import uuid4
from collections import Counter
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

MIN_PLAYERS = 5


class Phase(StrEnum):
    LOBBY = "lobby"
    NIGHT = "night"
    DISCUSSION = "discussion"
    VOTING = "voting"
    FINISHED = "finished"


class Role(StrEnum):
    MAFIA = "mafia"
    DOCTOR = "doctor"
    DETECTIVE = "detective"
    CITIZEN = "citizen"


class Team(StrEnum):
    TOWNSPEOPLE = "townspeople"
    MAFIA = "mafia"


@dataclass
class Player:
    user_id: int
    name: str
    username: str | None = None
    role: Role | None = None
    alive: bool = True
    badge: str | None = None
    protection_active: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "user_id": self.user_id,
            "name": self.name,
            "username": self.username,
            "role": self.role.value if self.role else None,
            "alive": self.alive,
            "badge": self.badge,
            "protection_active": self.protection_active,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Player:
        role = Role(data["role"]) if data.get("role") else None
        return cls(
            user_id=int(data["user_id"]),
            name=str(data["name"]),
            username=data.get("username"),
            role=role,
            alive=bool(data.get("alive", True)),
            badge=data.get("badge"),
            protection_active=bool(data.get("protection_active", False)),
        )


@dataclass
class Game:
    group_id: int
    group_title: str
    creator_id: int
    game_id: str = field(default_factory=lambda: uuid4().hex)
    phase: Phase = Phase.LOBBY
    round_number: int = 1
    deadline: float | None = None
    lobby_message_id: int | None = None
    players: dict[int, Player] = field(default_factory=dict)
    mafia_votes: dict[int, int] = field(default_factory=dict)
    doctor_target: int | None = None
    detective_target: int | None = None
    day_votes: dict[int, int] = field(default_factory=dict)

    @property
    def living_players(self) -> list[Player]:
        return [player for player in self.players.values() if player.alive]

    @property
    def living_mafia(self) -> list[Player]:
        return [
            player
            for player in self.living_players
            if player.role == Role.MAFIA
        ]

    def add_player(self, player: Player) -> str:
        if self.phase != Phase.LOBBY:
            return "closed"
        if player.user_id in self.players:
            return "already_joined"
        self.players[player.user_id] = player
        return "joined"

    def assign_roles(self, rng: Any = random) -> None:
        if self.phase != Phase.LOBBY:
            raise ValueError("Roles can only be assigned from the lobby.")
        if len(self.players) < MIN_PLAYERS:
            raise ValueError(f"At least {MIN_PLAYERS} players are required.")

        player_count = len(self.players)
        mafia_count = 2 if player_count >= 8 else 1
        roles = [Role.MAFIA] * mafia_count
        roles.extend([Role.DOCTOR, Role.DETECTIVE])
        roles.extend([Role.CITIZEN] * (player_count - len(roles)))
        rng.shuffle(roles)

        for player, role in zip(self.players.values(), roles, strict=True):
            player.role = role
            player.alive = True

    def begin_night(self, duration: int = 60, now: float | None = None) -> None:
        if any(player.role is None for player in self.living_players):
            raise ValueError("All players need a role before night begins.")
        self.phase = Phase.NIGHT
        self.deadline = (time.time() if now is None else now) + duration
        self.mafia_votes.clear()
        self.doctor_target = None
        self.detective_target = None
        self.day_votes.clear()

    def begin_discussion(
        self, duration: int = 60, now: float | None = None
    ) -> None:
        self.phase = Phase.DISCUSSION
        self.deadline = (time.time() if now is None else now) + duration
        self.day_votes.clear()

    def begin_voting(self, duration: int = 45, now: float | None = None) -> None:
        self.phase = Phase.VOTING
        self.deadline = (time.time() if now is None else now) + duration
        self.day_votes.clear()

    def finish(self) -> None:
        self.phase = Phase.FINISHED
        self.deadline = None

    def set_night_action(
        self, actor_id: int, action: str, target_id: int
    ) -> str:
        actor = self.players.get(actor_id)
        target = self.players.get(target_id)
        if self.phase != Phase.NIGHT:
            return "wrong_phase"
        if actor is None or target is None or not actor.alive or not target.alive:
            return "not_alive"
        if actor_id == target_id:
            return "self_target"

        if action == "mafia":
            if actor.role != Role.MAFIA or target.role == Role.MAFIA:
                return "invalid_target"
            self.mafia_votes[actor_id] = target_id
            return "saved"
        if action == "doctor":
            if actor.role != Role.DOCTOR:
                return "wrong_role"
            self.doctor_target = target_id
            return "saved"
        if action == "detective":
            if actor.role != Role.DETECTIVE:
                return "wrong_role"
            self.detective_target = target_id
            return "saved"
        return "invalid_action"

    def night_actions_complete(self) -> bool:
        mafia_done = all(
            player.user_id in self.mafia_votes for player in self.living_mafia
        )
        doctor = next(
            (
                player
                for player in self.living_players
                if player.role == Role.DOCTOR
            ),
            None,
        )
        detective = next(
            (
                player
                for player in self.living_players
                if player.role == Role.DETECTIVE
            ),
            None,
        )
        doctor_done = doctor is None or self.doctor_target is not None
        detective_done = detective is None or self.detective_target is not None
        return mafia_done and doctor_done and detective_done

    def resolve_night(self) -> tuple[Player | None, bool, bool, bool]:
        if self.phase != Phase.NIGHT:
            raise ValueError("Night can only be resolved during the night.")

        living_ids = {player.user_id for player in self.living_players}
        valid_votes = [
            target_id
            for voter_id, target_id in self.mafia_votes.items()
            if voter_id in living_ids
            and target_id in living_ids
            and self.players[voter_id].role == Role.MAFIA
            and self.players[target_id].role != Role.MAFIA
        ]
        counts = Counter(valid_votes)
        tied = False
        target_id: int | None = None
        if counts:
            highest = max(counts.values())
            leaders = [key for key, count in counts.items() if count == highest]
            tied = len(leaders) > 1
            if not tied:
                target_id = leaders[0]

        saved = target_id is not None and target_id == self.doctor_target
        shield_saved = False
        eliminated = None
        if target_id is not None and not saved:
            eliminated = self.players[target_id]
            if eliminated.protection_active:
                eliminated.protection_active = False
                shield_saved = True
                eliminated = None
            else:
                eliminated.alive = False
        return eliminated, saved, tied, shield_saved

    def cast_day_vote(self, voter_id: int, target_id: int) -> str:
        voter = self.players.get(voter_id)
        target = self.players.get(target_id)
        if self.phase != Phase.VOTING:
            return "wrong_phase"
        if voter is None or target is None or not voter.alive or not target.alive:
            return "not_alive"
        if voter_id == target_id:
            return "self_target"
        self.day_votes[voter_id] = target_id
        return "saved"

    def voting_complete(self) -> bool:
        return all(
            player.user_id in self.day_votes for player in self.living_players
        )

    def resolve_day_vote(self) -> tuple[Player | None, bool]:
        if self.phase != Phase.VOTING:
            raise ValueError("Voting can only be resolved during the voting phase.")

        living_ids = {player.user_id for player in self.living_players}
        valid_votes = [
            target_id
            for voter_id, target_id in self.day_votes.items()
            if voter_id in living_ids
            and target_id in living_ids
            and voter_id != target_id
        ]
        counts = Counter(valid_votes)
        if not counts:
            return None, False
        highest = max(counts.values())
        leaders = [key for key, count in counts.items() if count == highest]
        if len(leaders) != 1:
            return None, True

        eliminated = self.players[leaders[0]]
        eliminated.alive = False
        return eliminated, False

    def winner(self) -> Team | None:
        mafia_count = len(self.living_mafia)
        townspeople_count = len(self.living_players) - mafia_count
        if mafia_count == 0:
            return Team.TOWNSPEOPLE
        if mafia_count >= townspeople_count:
            return Team.MAFIA
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "game_id": self.game_id,
            "group_id": self.group_id,
            "group_title": self.group_title,
            "creator_id": self.creator_id,
            "phase": self.phase.value,
            "round_number": self.round_number,
            "deadline": self.deadline,
            "lobby_message_id": self.lobby_message_id,
            "players": [player.to_dict() for player in self.players.values()],
            "mafia_votes": {
                str(key): value for key, value in self.mafia_votes.items()
            },
            "doctor_target": self.doctor_target,
            "detective_target": self.detective_target,
            "day_votes": {
                str(key): value for key, value in self.day_votes.items()
            },
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Game:
        game = cls(
            group_id=int(data["group_id"]),
            group_title=str(data.get("group_title", "Guruh")),
            creator_id=int(data["creator_id"]),
            game_id=str(data.get("game_id", uuid4().hex)),
            phase=Phase(data.get("phase", Phase.LOBBY.value)),
            round_number=int(data.get("round_number", 1)),
            deadline=data.get("deadline"),
            lobby_message_id=data.get("lobby_message_id"),
            players={
                player.user_id: player
                for player in (
                    Player.from_dict(item) for item in data.get("players", [])
                )
            },
            mafia_votes={
                int(key): int(value)
                for key, value in data.get("mafia_votes", {}).items()
            },
            doctor_target=data.get("doctor_target"),
            detective_target=data.get("detective_target"),
            day_votes={
                int(key): int(value)
                for key, value in data.get("day_votes", {}).items()
            },
        )
        if game.doctor_target is not None:
            game.doctor_target = int(game.doctor_target)
        if game.detective_target is not None:
            game.detective_target = int(game.detective_target)
        return game
